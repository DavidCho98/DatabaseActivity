
package business;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;

import beans.Order;
import data.OrdersDataService;

/**
 * Session Bean implementation class AnotherBusinessService
 */
@Stateless
@Local(OrderBusinessInterface.class)
@LocalBean
@Alternative

public class AnotherBusinessService implements OrderBusinessInterface {

List<Order> orders = new ArrayList<Order>();
    
    public AnotherBusinessService() {
//        orders.add(new Order("0000000000", "This is Product 1 Snickers", (float) 1.00, 1));
//        orders.add(new Order("0000000001", "This is Product 2 Snickers", (float) 2.00, 2));
//        orders.add(new Order("0000000002", "This is Product 3 Snickers", (float) 3.00, 3));
//        orders.add(new Order("0000000003", "This is Product 4 Snickers", (float) 4.00, 4));
//        orders.add(new Order("0000000004", "This is Product 5 Snickers", (float) 5.00, 5));
    }

    @Override
    public void test() {
        // TODO Auto-generated method stub
        System.out.println("Welcome to the Product page. :) ");
        
    }

    @Override
    public List<Order> getOrders() {
        return orders;
    }

    @Override
    public void setOrder(List<Order> orders) {
        this.orders = orders;        
    }

	@Override
	public OrdersDataService getService() {
		// TODO Auto-generated method stub
		return null;
	}



}
