
package business;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;

import beans.Order;
import data.OrdersDataService;

/**
 * Session Bean implementation class OrderBusinessService
 */
@Stateless
@Local(OrderBusinessInterface.class)
@LocalBean
@Alternative
public class OrderBusinessService implements OrderBusinessInterface {

	//calling the crud to utilize em in the controller. 
	@EJB
	OrdersDataService service;
	
	//list of Order in the array list
	List<Order> orders = new ArrayList<Order>();
	
	public OrdersDataService getService(){
		
    	return service;
    }
	//constructor
    public OrderBusinessService() {
        
    
    }

    //testing the logger on the console everytime we go through this class. 
    @Override
    public void test() {
        // TODO Auto-generated method stub
        System.out.println("BusinessService.test");
    }

    //getters and setters
    @Override
    public List<Order> getOrders() {
        //return orders;
    	return service.findAll();
    }

    @Override
    public void setOrder(List<Order> orders) {
        this.orders = orders;        
    }

    //findAll methods to see if the data base were showing without using the Nlayer architecture
    public List<Order> findAll(){
		
		Connection conn = null;
		String url = "jdbc:postgresql://localhost:5432/postgres";
		String username = "postgres";
		String password = "root";
		String sql = "SELECT * FROM testapp.orders";
		List<Order> orders = new ArrayList<Order>();
		
		
			
		try {
			
			conn = DriverManager.getConnection(url,username, password);
			
		Statement stmt = conn.createStatement();
		
		ResultSet rs = stmt.executeQuery(sql);
		
		
		
		while (rs.next()){
			orders.add (new Order(rs.getString("order_no"),
								  rs.getString("product_name"),
								  rs.getFloat("price"),
								  rs.getInt("quantity")));
		}
		
		rs.close();
		}catch(SQLException e){
			e.printStackTrace();
			
		}
		finally {
			if(conn != null) 
			{
				try 
				{
					conn.close();
				}
				catch(SQLException e){
					
					e.printStackTrace();
					
				}
			}
		}
		return orders;
	}
}
