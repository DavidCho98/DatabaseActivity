

package controllers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import beans.Order;
//import beans.Orders;
import beans.User;
import business.MyTimerService;
import business.OrderBusinessInterface;


@ManagedBean
@ViewScoped
public class FormController {
	
	@Inject
	OrderBusinessInterface service;
	
	@EJB
	MyTimerService timer;
	
	// when you submit(pressing loggin button) things that are below will happen.
	// specific comments are explained in the console as the app is running. 
	public String onSubmit(User user)
	{
	
		service.test();
		System.out.println(",,,,,,,,,,,Getting Orders**********");
		System.out.println(service.getService().findAll());
		System.out.println(",,,,,,,,,,,,Inserting a new order into testapp database*************");
		service.getService().create(new Order("001122334455", "This was inserted new", (float)25.00, 100));
		System.out.println(",,,,,,,,,,,,Inserted a new order and getting the orders again from the data*************");
		System.out.println(service.getService().findAll());
		System.out.println(",,,,,,,,,,,Activity completed**********");
		
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("user", user);
		
		return "TestResponse.xhtml";
		
	}
	


	
	public OrderBusinessInterface getService() {
		return service;
	}
}
