package data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import beans.Order;

/**
 * Session Bean implementation class OrdersDataService
 */
@Stateless
@Local(DataAccessInterface.class)
@LocalBean
public class OrdersDataService implements DataAccessInterface {

    /**
     * Default constructor. 
     */
    public OrdersDataService() {
        // TODO Auto-generated constructor stub
    }


    //find all the orders in the database and displaying in the test response
    
	@Override
	public List<Order> findAll() {
		Connection conn = null;
		String url = "jdbc:postgresql://localhost:5432/postgres";
		String username = "postgres";
		String password = "root";
		String sql = "SELECT * FROM testapp.orders";
		List<Order> orders = new ArrayList<Order>();
		
		try
		{
			conn = DriverManager.getConnection(url, username, password);
			
			System.out.println("Successfully connected to the database!"); 
			
			Statement stmt = conn.createStatement();
			 
			
			ResultSet rs = stmt.executeQuery(sql);
			
			
			
			while(rs.next())
			{
				orders.add(new Order(rs.getString("order_no"), rs.getString("product_name"), rs.getFloat("price"), rs.getInt("quantity")));
			}
			//cleanup result set
			rs.close();
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			System.out.println("Failed to connect to the database!");
		}
		finally
		{
			//Cleanup Database
			if(conn != null)
			{
				try
				{
					conn.close();
				}
				catch(SQLException e)
				{
					e.printStackTrace();
				}
			}
		}

		return orders;
	}

	// using query INSERT INTO to create a product to put in the database from the exlipse itself. 
	@Override
	public boolean create(Order order) {
		Connection conn = null;
        String url = "jdbc:postgresql://localhost:5432/postgres";
        String username = "postgres";
        String password = "root";
        String sql = "INSERT INTO testapp.orders(order_no, product_name, price, quantity) VALUES('99998888000555446', 'New Pause for the Cause', 22.00, 100)";

        try 
        {
            conn = DriverManager.getConnection(url, username, password);
            System.out.println("Successfully connected to the database!"); 
            
            
            Statement stmt = conn.createStatement();
         
            
            
            stmt.executeUpdate(sql);
            
            
        } 
        
        catch (SQLException e) 
        {
            e.printStackTrace();
            System.out.println("Failed to connect to the database!");
        }
        finally
        {
            if(conn != null)
            {
                try 
                {
                    conn.close();
                } 
                catch (SQLException e) 
                {
                    e.printStackTrace();
                }
            }
        }
		return true;
	}
	@Override
	public boolean delete(Order order) {
		// TODO Auto-generated method stub
		return false;
	}

	
//	@Override
//	public boolean read(int id) {
//		// TODO Auto-generated method stub
//		return false;
//	}

	@Override
	public boolean update(Order order) {
		// TODO Auto-generated method stub
		return true;
	}

}
