package data;

import java.util.List;

import beans.Order;

public interface DataAccessInterface {
	//crud methods from the orders data service so that way we can call these in the business service.
	public List<Order> findAll();
	public boolean create(Order order);
	public boolean update(Order order);
	public boolean delete(Order order);
}
